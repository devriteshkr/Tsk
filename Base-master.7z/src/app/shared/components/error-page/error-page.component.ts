import { Component } from '@angular/core';

@Component({
    selector:'taskina-error',
    templateUrl:'./error-page.component.html'
})

export  class ErrorPageComponent
{

}