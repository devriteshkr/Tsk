import { Component } from '@angular/core';

@Component({
    selector: 'taskina-browse-task',
    templateUrl: './browse-task.component.html',
    styleUrls: ['./browse-task.component.scss']
})

export class BrowseTaskComponent {
    title = 'Browse Tasks !';
}