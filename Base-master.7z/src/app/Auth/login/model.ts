export class LoginDialog {
    constructor (
        public email?: string,
        public password?: string
    ) {}
}
