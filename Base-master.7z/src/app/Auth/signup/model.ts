export class SignupDialog {
    public email: string;
    public password: string
}
